package core;

public enum RSCategory {
    FP_ADD,
    FP_MUL,
    INT_ALU,
    LOAD,
    STORE
}
