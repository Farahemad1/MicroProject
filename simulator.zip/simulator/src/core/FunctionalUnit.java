package core;

public class FunctionalUnit {

}
